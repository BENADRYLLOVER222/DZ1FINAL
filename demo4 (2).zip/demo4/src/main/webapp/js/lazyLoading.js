// Функция, которая будет вызываться при прокрутке страницы
$(window).scroll(function() {
    // Проверяем, достигли ли мы конца страницы
    if($(window).scrollTop() + $(window).height() === $(document).height()) {
        // Если достигли конца страницы, отправляем AJAX запрос на сервер
        $.ajax({
            type: "GET",
            url: "MyController?command=load_more_news", // URL для загрузки дополнительных новостей
            data: { offset: $('.card').length, limit: 10 }, // Параметры для запроса (смещение и лимит)
            success: function(data) {
                // В случае успешного ответа от сервера
                // Добавляем полученные новости в конец списка новостей
                $('#newsContainer').append(data);
            }
        });
    }
});