        function changeMainImage(element) {
            const mainImage = document.querySelector('.mainImage img');
            mainImage.src = element.src;
        }