package first.second.third.dao;

import first.second.third.dao.impl.CommentManagerDaoImpl;
import first.second.third.dao.impl.NewsManagerDaoImpl;
import first.second.third.dao.impl.TagManagerDaoImpl;
import first.second.third.dao.impl.UserManagerDaoImpl;

public final class DaoProvider {
    private static final DaoProvider instance = new DaoProvider();

    private final NewsManagerDao newsManagerDao = NewsManagerDaoImpl.getInstance();
    private final TagManagerDao tagManagerDao = TagManagerDaoImpl.getInstance();
    private final UserManagerDao userManagerDao = UserManagerDaoImpl.getInstance();
    private final CommentManagerDao commentManagerDao = CommentManagerDaoImpl.getInstance();

    private DaoProvider() {}

    public static DaoProvider getInstance() {return instance;}

    public TagManagerDao getTagManagerDao() { return tagManagerDao;}
    public NewsManagerDao getNewsManagerDao() {return newsManagerDao;}
    public UserManagerDao getUserManagerDao() {return userManagerDao;}
    public CommentManagerDao getCommentManagerDao() {return commentManagerDao;}
}