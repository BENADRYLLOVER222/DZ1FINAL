package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;
import first.second.third.utils.Validator;

import java.io.IOException;
import java.util.Collection;
import java.util.ArrayList;

public class UserPrivChange implements Command {
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);
        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User userSession = (User) request.getSession().getAttribute("user");
        if (validator.validateAdmin(userSession.getRole())) {
            try {
                // Перебираем всех пользователей
                Collection<User> allUsers = new ArrayList<>(userManager.getAllUsers());
                for (User user : allUsers) {
                    // ваш код обработки пользователей
                    // Формируем имя параметра для имени пользователя и новой роли
                    String usernameParam = "username_" + user.getId();
                    String newRoleParam = "newRole_" + user.getId();

                    String username = request.getParameter(usernameParam);
                    String newRole = request.getParameter(newRoleParam);
                    System.out.println("username: " + username);
                    System.out.println("newRole: " + newRole);

                    if (username != null && !username.isEmpty() && newRole != null && !newRole.isEmpty()) {
                        if(validator.validateRole(newRole)){
                            userManager.updateUserRole(username, newRole);
                        }else {
                            response.sendRedirect("MyController?command=go_to_error_page&error=This role does not exists");
                            return;
                        }
                        System.out.println();
                    }
                }
                response.sendRedirect("MyController?command=go_to_user_manager");
            } catch (ServiceException | UtilException e) {
                response.sendRedirect("MyController?command=go_to_error_page&error=Something went wrong");
            }
        }
    }
}