package first.second.third.controller.concrete.impl;

import first.second.third.bean.Comment;
import first.second.third.bean.News;
import first.second.third.bean.Tag;
import first.second.third.controller.concrete.Command;
import first.second.third.dao.impl.CommentManagerDaoImpl;
import first.second.third.service.*;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class GoToNewsDetails implements Command {
    private final NewsManager newsManager = ServiceProvider.getInstance().getNewsManager();
    private final CommentManager commentManager = ServiceProvider.getInstance().getCommentManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Retrieve the user's session
        HttpSession session = request.getSession(false); // Retrieve the session without creating a new one if it doesn't exist
        if (validator.sessionPresence(session) && validator.userPresence(session.getAttribute("user"))) {
            // User is authenticated, proceed with retrieving news details
            try {
                String newsIdStr = request.getParameter("id");
                long newsId = Long.parseLong(newsIdStr);
                News news = newsManager.getNewsById(newsId);
                if (news != null) {
                    List<Comment> comments = commentManager.getCommentsByEntityId(newsId, CommentManagerDaoImpl.EntityType.NEWS);
                    List<Tag> tags = newsManager.getTagsByNewsId(newsId);
                    Collection<News> allNews = newsManager.getAllNews();
                    List<News> allNewsList = new ArrayList<>(allNews);
                    List<News> lastThreeNews = new ArrayList<>();
                    int size = allNewsList.size();
                    int newsCount = Math.min(3, size);
                    for (int i = 0; i < newsCount; i++) {
                        lastThreeNews.add(allNewsList.get(size - 1 - i));
                    }
                    request.setAttribute("comments", comments);
                    request.setAttribute("news_s", news);
                    request.setAttribute("tags", tags);
                    request.setAttribute("three_news", lastThreeNews);
                    RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/news-details.jsp");
                    dispatcher.forward(request, response);
                } else {
                    response.sendRedirect("MyController?command=go_to_error_page&error=News not found");
                }
            } catch (ServiceException | NumberFormatException e) {
                response.sendRedirect("MyController?command=go_to_error_page&error=News not found");
            }
        } else {
            // User is not authenticated, redirect to login page
            response.sendRedirect("MyController?command=go_to_index_page&authError=You cannot perform this action. Please log in!");
        }
    }
}