package first.second.third.dao;

import first.second.third.bean.Comment;
import first.second.third.dao.impl.CommentManagerDaoImpl;

import java.util.List;

public interface CommentManagerDao {

    long addComment(long userId, long entityId, String commentText, CommentManagerDaoImpl.EntityType entityType) throws DaoException;
    int countUserComments(long userId) throws DaoException;
    List<Comment> getCommentsByEntityId(long entityId, CommentManagerDaoImpl.EntityType entityType) throws DaoException;
    void deleteComment(long commentId) throws DaoException;
}