package first.second.third.controller.filter;

import first.second.third.bean.User;
import jakarta.servlet.Filter;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpFilter;
import java.io.IOException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;

public class RememberMeFilter extends HttpFilter implements Filter {
    private final static long serialVersionUID = 1L;
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();

    public RememberMeFilter() {
        super();
    }

    public void destroy() {
    }


    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        try {
            HttpSession session = ((HttpServletRequest) request).getSession(false);

            if (session == null || session.getAttribute("user") == null) {
                Cookie[] cookies = ((HttpServletRequest) request).getCookies();
                if (cookies != null) {
                    for (Cookie c : cookies) {
                        if (c.getName().equals("remember-me")) {
                            long userID = Long.parseLong(c.getValue());
                            User user = userManager.getUserById(userID);
                            if (user != null) {
                                ((HttpServletRequest) request).getSession().setAttribute("user", user);
                                HttpSession session_create = ((HttpServletRequest) request).getSession(true);
                                break;
                            }
                        }
                    }
                }
            }
            chain.doFilter(request, response);
        } catch (ServiceException | NumberFormatException e) {
            e.printStackTrace();
        }
    }

    public void init(FilterConfig fConfig) throws ServletException {

    }

}
