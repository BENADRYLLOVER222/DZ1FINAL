package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;
import first.second.third.utils.Validator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class GoToUserManager implements Command {
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private static final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            HttpSession session = request.getSession(false);
            if (validator.sessionPresence(session) && validator.userPresence(session.getAttribute("user"))) {
                // Get the user object from the session
                User user = (User) session.getAttribute("user");

                // Check if the user is an admin or moderator
                if (validator.validateMod(user.getRole())) {
                    Collection<User> users = userManager.getAllUsers();
                    Collection<User> adminsAndMods = new ArrayList<>();
                    List<User> muted = new ArrayList<>();

                    // Filter users to separate admins and moderators
                    for (User u : users) {
                        if (!validator.validateUser(u.getRole()) && !validator.validateMuted(u.getRole())) {
                            adminsAndMods.add(u);
                        } else if (u.getRole().equalsIgnoreCase("muted")) {
                            muted.add(u);
                        }
                    }

                    // Set attributes for admins and moderators
                    request.setAttribute("admins", adminsAndMods);
                    request.setAttribute("muted", muted);

                    // Forward the request to the appropriate JSP page
                    RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/adminlist.jsp");
                    dispatcher.forward(request, response);
                } else {
                    // If the user is neither an admin nor a moderator, redirect them
                    RequestDispatcher dispatcher = request.getRequestDispatcher("MyController?command=go_to_index_page&authError=You are not authorized to access this page.");
                    dispatcher.forward(request, response);
                }
            } else {
                // If the user is not authenticated, redirect them
                RequestDispatcher dispatcher = request.getRequestDispatcher("MyController?command=go_to_index_page&authError=You cannot perform this action. Please log in!");
                dispatcher.forward(request, response);
            }
        } catch (ServiceException e) {
            // Handle service exceptions
            response.sendRedirect("MyController?command=go_to_error_page&error=An error occurred during getting users.");
        }
    }
}