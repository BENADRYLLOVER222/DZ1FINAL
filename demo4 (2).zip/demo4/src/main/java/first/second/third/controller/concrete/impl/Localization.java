package first.second.third.controller.concrete.impl;

import first.second.third.controller.concrete.Command;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class Localization implements Command {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getSession(true).setAttribute("local", request.getParameter("local"));
        response.sendRedirect("MyController?command=go_to_main_page");
    }
}
