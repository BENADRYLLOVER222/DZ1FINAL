package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;
import first.second.third.utils.Validator;

import java.io.IOException;

public class UserRemoveFromBlacklist implements Command {
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);

        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        if (validator.validateMod(user.getRole())) {
            // Получаем имя пользователя, которого нужно разблокировать, из запроса
            String mutedUserName = request.getParameter("mutedUserName");
            // Если имя пользователя не пустое
            if (mutedUserName != null && !mutedUserName.isEmpty()) {
                try {
                    // Обновляем роль пользователя на 'user'
                    userManager.updateUserRole(mutedUserName, "user");
                } catch (ServiceException e) {
                    // Если произошла ошибка, перенаправляем пользователя на страницу ошибки
                    response.sendRedirect("MyController?command=go_to_error_page&error=Something went wrong");
                }
            }

            // Перенаправляем пользователя на страницу управления пользователями
            response.sendRedirect("MyController?command=go_to_user_manager");
        }
    }
}