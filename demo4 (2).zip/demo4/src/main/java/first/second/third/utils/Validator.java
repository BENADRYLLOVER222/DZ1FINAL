package first.second.third.utils;

import first.second.third.bean.RegInfo;
import first.second.third.service.ServiceException;
import jakarta.servlet.http.HttpSession;

public interface Validator {
    void regValidator(RegInfo regInfo) throws UtilException;

    void validateAuth(HttpSession session, Validator validator) throws UtilException;

    boolean validateRole(String role) throws UtilException;

    boolean validateAdmin(String role);

    boolean validateMod(String role);

    boolean validateEditor(String role);

    boolean validateMuted(String role);

    boolean userPresence(Object user);

    boolean sessionPresence(HttpSession session);

    boolean validateId(long id1, long id2);

    boolean validateUser(String role);

    boolean containsProfanity(String text) throws UtilException;



}
