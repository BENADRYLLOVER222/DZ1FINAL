package first.second.third.controller.concrete.impl;

import first.second.third.bean.AuthInfo;
import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;

import java.io.IOException;

public class DoAuth implements Command {
	private final UserManager userService = ServiceProvider.getInstance().getUserManager();

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String login = request.getParameter("login");
		String password = request.getParameter("password");


		try {
			User user = userService.signIn(new AuthInfo(login, password));
			if (user != null) {
				HttpSession session = request.getSession(true);
				user.setPassword(null);
				session.setAttribute("user", user);


				String rememberMe = request.getParameter("rememberMe");
				if (rememberMe != null) {
					Cookie cookie = new Cookie("remember-me", String.valueOf(user.getId()));
					cookie.setSecure(true);
					cookie.setHttpOnly(true);
					response.addCookie(cookie);
				}

				response.sendRedirect("MyController?command=go_to_main_page");
			} else {
				response.sendRedirect("MyController?command=go_to_index_page&authError=Wrong login or password!");
			}
		} catch (ServiceException e) {
			System.out.println("Error during user authentication and authorization. Login: " + login);
			response.sendRedirect("MyController?command=go_to_index_page&authError=An error occurred during authentication.");
		}
	}
}