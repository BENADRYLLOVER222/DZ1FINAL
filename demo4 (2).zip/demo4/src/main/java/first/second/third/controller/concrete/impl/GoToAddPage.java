package first.second.third.controller.concrete.impl;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.utils.Validator;

public class GoToAddPage implements Command {
	Validator validator = UtilsProvider.getInstance().getValidator();
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		try {
			validator.validateAuth(session, validator);
		} catch (UtilException e) {
			response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
			return;
		}
		User user = (User) session.getAttribute("user");

		String role = user.getRole();
		if (!(validator.validateEditor(role))) {
			response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("Unauthorized access", StandardCharsets.UTF_8));
			return;
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/add.jsp");
		dispatcher.forward(request, response);
	}
}
