package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.service.*;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;

public class CommentDeleteMute implements Command {
    private final CommentManager commentManager = ServiceProvider.getInstance().getCommentManager();
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");

        String role = user.getRole();
        if (!validator.validateMod(role)) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("Permission denied", StandardCharsets.UTF_8));
            return;
        }
        long commentId;
        long newsId;
        String username;
        try {
            commentId = Long.parseLong(request.getParameter("commentId"));
            newsId = Long.parseLong(request.getParameter("newsId"));
            username = request.getParameter("username");
        } catch (NumberFormatException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("Invalid parameters", StandardCharsets.UTF_8));
            return;
        }
        try {
            userManager.addUserToBlacklist(username);
            commentManager.deleteComment(commentId);
            response.sendRedirect("MyController?command=go_to_news_details&id=" + newsId);
        } catch (ServiceException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("Service error: " + e.getMessage(), StandardCharsets.UTF_8));
        }
    }
}