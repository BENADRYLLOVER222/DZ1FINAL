package first.second.third.controller.concrete.impl;

import first.second.third.bean.Comment;
import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.dao.impl.CommentManagerDaoImpl;
import first.second.third.service.*;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collection;

public class GoToUserProfile implements Command {
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private final CommentManager commentManager = ServiceProvider.getInstance().getCommentManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        HttpSession session = request.getSession(false);
        try{
            validator.validateAuth(session, validator);
        }catch(UtilException e){
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        String userIdString = request.getParameter("id");

        if (userIdString == null || userIdString.isEmpty()) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("User ID is missing", StandardCharsets.UTF_8));
            return;
        }

        try {
            long userId = Long.parseLong(userIdString);
            User profGen = userManager.getUserById(userId);
            Collection<Comment> comments = commentManager.getCommentsByEntityId(userId, CommentManagerDaoImpl.EntityType.PROFILE);
            int comCounter = commentManager.countUserComments(userId);

            request.setAttribute("comCounter", comCounter);
            request.setAttribute("user", profGen);
            request.setAttribute("comments", comments);
            request.getRequestDispatcher("WEB-INF/jsp/profile.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("Invalid user ID format", StandardCharsets.UTF_8));
        } catch (ServiceException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("An error occurred during getting user", StandardCharsets.UTF_8));
        }
    }
}
