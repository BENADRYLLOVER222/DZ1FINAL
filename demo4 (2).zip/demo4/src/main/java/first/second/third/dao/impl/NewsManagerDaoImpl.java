package first.second.third.dao.impl;

import first.second.third.bean.News;
import first.second.third.bean.Tag;
import first.second.third.bean.User;
import first.second.third.dao.config.ConnectionPool;
import first.second.third.dao.config.ConnectionPoolException;
import first.second.third.dao.DaoException;
import first.second.third.dao.NewsManagerDao;

import java.sql.*;
import java.util.*;

public class NewsManagerDaoImpl implements NewsManagerDao {
    private static final NewsManagerDaoImpl instance = new NewsManagerDaoImpl();
    private static final ConnectionPool connectionPool = ConnectionPool.getInstance();

    // Статический список новостей
    //private final Map<Long, News> newsList = new HashMap<>();

    // Приватный конструктор для предотвращения создания экземпляров
    private NewsManagerDaoImpl() {
        // Пустой приватный конструктор
    }
    public static NewsManagerDaoImpl getInstance() {
        return instance;
    }

    private final static String getAllNewsSql = "SELECT n.id, n.title, n.brief, n.info, n.img_path, " +
            "u.id AS author_id, " +
            "t.id AS tag_id, t.name AS tag_name " +
            "FROM news n " +
            "LEFT JOIN news_tags nt ON n.id = nt.news_id " +
            "LEFT JOIN tags t ON nt.tag_id = t.id " +
            "LEFT JOIN news_author na ON n.id = na.news_id " +
            "LEFT JOIN users_table u ON na.author_id = u.id " +
            "WHERE n.is_active = true";
    private static final String updateNewsByIdSql = "UPDATE news SET title = ?, brief = ?, info = ?, img_path = ? WHERE id = ?";
    private static final String getNewsByTagIdSql = "SELECT n.id, n.title, n.brief, n.info, n.img_path, " +
            "u.id AS author_id, u.name AS author_name, r.role AS author_role, " +
            "t.id AS tag_id, t.name AS tag_name " +
            "FROM news n " +
            "JOIN news_tags nt ON n.id = nt.news_id " +
            "JOIN tags t ON nt.tag_id = t.id " +
            "LEFT JOIN news_author na ON n.id = na.news_id " +
            "LEFT JOIN users_table u ON na.author_id = u.id " +
            "LEFT JOIN user_role r ON u.id = r.user_id " +
            "WHERE nt.tag_id = ? AND n.is_active = true";
    private static final String deleteNewsByIdSql = "UPDATE news SET is_active = false WHERE id = ?";
    private static final String getTagsByNewsIdSql = "SELECT t.id, t.name FROM tags t JOIN news_tags nt ON t.id = nt.tag_id WHERE nt.news_id = ?";
    private static final String getNewsByIdSqL = "SELECT n.id, n.title, n.brief, n.info, n.img_path, " +
            "u.id AS author_id, u.name AS author_name, r.role AS author_role, " +
            "t.id AS tag_id, t.name AS tag_name " +
            "FROM news n " +
            "LEFT JOIN news_tags nt ON n.id = nt.news_id " +
            "LEFT JOIN tags t ON nt.tag_id = t.id " +
            "LEFT JOIN news_author na ON n.id = na.news_id " +
            "LEFT JOIN users_table u ON na.author_id = u.id " +
            "LEFT JOIN user_role r ON u.id = r.user_id " +
            "WHERE n.is_active = true AND n.id = ?";


    public void updateNewsById(long id, String title, String brief, String info, String imgPath) throws DaoException {
        // Обновление новости в базе данных
        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement(updateNewsByIdSql)) {

            // Устанавливаем параметры запроса
            stmt.setString(1, title);
            stmt.setString(2, brief);
            stmt.setString(3, info);
            stmt.setString(4, imgPath);
            stmt.setLong(5, id);

            // Выполняем запрос на обновление данных новости
            int rowsAffected = stmt.executeUpdate();

            // Проверяем, была ли обновлена хотя бы одна запись
            if (rowsAffected == 0) {
                throw new DaoException("News with ID " + id + " not found.");
            }

        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Failed to update news.", e);
            // Вы можете добавить обработку исключений, например, логирование или бросить исключение выше
        }
    }


    @Override
    public List<News> getNewsByTagId(long tagId) throws DaoException {
        Map<Long, News> newsMap = new HashMap<>();

        String query = getNewsByTagIdSql;

        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setLong(1, tagId);
            ResultSet rs = stmt.executeQuery();

            Map<Long, List<Tag>> newsTagsMap = new HashMap<>();
            Map<Long, Long> newsAuthorsMap = new HashMap<>();

            while (rs.next()) {
                long newsId = rs.getLong("id");
                String title = rs.getString("title");
                String brief = rs.getString("brief");
                String info = rs.getString("info");
                String imgPath = rs.getString("img_path");
                long authorId = rs.getLong("author_id");
                String authorName = rs.getString("author_name");
                String authorRole = rs.getString("author_role");

                News news = newsMap.computeIfAbsent(newsId, k -> new News(newsId, title, brief, info, imgPath));

                if (authorId != 0) {
                    newsAuthorsMap.put(newsId, authorId);
                }

                long retrievedTagId = rs.getLong("tag_id");
                String tagName = rs.getString("tag_name");

                if (retrievedTagId != 0) {
                    newsTagsMap.computeIfAbsent(newsId, k -> new ArrayList<>()).add(new Tag(retrievedTagId, tagName));
                }
            }

            for (Map.Entry<Long, List<Tag>> entry : newsTagsMap.entrySet()) {
                long newsId = entry.getKey();
                List<Tag> tags = entry.getValue();
                News news = newsMap.get(newsId);
                if (news != null) {
                    news.setTags(tags);
                }
            }

            UserManagerDaoImpl userManagerDao = UserManagerDaoImpl.getInstance();
            for (Map.Entry<Long, Long> entry : newsAuthorsMap.entrySet()) {
                long newsId = entry.getKey();
                long authorId = entry.getValue();
                News news = newsMap.get(newsId);
                if (news != null) {
                    try {
                        User author = userManagerDao.getUserById(authorId);
                        news.setAuthor(author);
                    } catch (DaoException e) {
                        throw new DaoException(e);
                    }
                }
            }

            if (newsMap.isEmpty()) {
                throw new DaoException("News not found by tag ID: " + tagId);
            }

            return new ArrayList<>(newsMap.values());
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error fetching news by tag ID", e);
        }
    }
    @Override
    public void deleteNewsById(long id) throws DaoException {
        try (Connection connection = connectionPool.takeConnection()) {
            // Начинаем транзакцию
            connection.setAutoCommit(false);

            try (PreparedStatement updateNewsStmt = connection.prepareStatement(deleteNewsByIdSql)) {
                // Обновление новости в news
                updateNewsStmt.setLong(1, id);
                int newsRowsAffected = updateNewsStmt.executeUpdate();
                // Проверяем, была ли обновлена хотя бы одна запись
                if (newsRowsAffected == 0) {
                    throw new DaoException("News with ID " + id + " not found.");
                }

                // Фиксируем транзакцию
                connection.commit();

            } catch (SQLException e) {
                connection.rollback();
                throw new DaoException("Failed to update news.", e);
            } finally {
                // Возвращаем автоматическое управление транзакциями
                connection.setAutoCommit(true);
            }

            // Обновляем список новостей после обновления
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Failed to establish database connection.", e);
        }
    }

    @Override
    public List<Tag> getTagsByNewsId(long newsId) throws DaoException {
        List<Tag> tags = new ArrayList<>();
        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement(getTagsByNewsIdSql)) {

            stmt.setLong(1, newsId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                long tagId = rs.getLong("id");
                String tagName = rs.getString("name");
                tags.add(new Tag(tagId, tagName));
            }
        } catch (SQLException | ConnectionPoolException e) {
            // Обрабатываем SQLException
            throw new DaoException("Error fetching tags by news ID", e);
        }
        // Обновляем список новостей
        return tags;
    }

    @Override
    public long newsAdd(String title, String brief, String info, String imgPath, long authorId) throws DaoException {
        long newsId = -1;  // Переменная для хранения сгенерированного идентификатора

        // Добавление новости в базу данных
        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement("INSERT INTO news (title, brief, info, img_path) VALUES (?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {

            // Устанавливаем параметры запроса для вставки новости
            stmt.setString(1, title);
            stmt.setString(2, brief);
            stmt.setString(3, info);
            stmt.setString(4, imgPath);

            // Выполняем запрос на вставку новой записи
            stmt.executeUpdate();

            // Получаем сгенерированный ключ (id) новости
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                newsId = rs.getLong(1);  // Сохраняем сгенерированный идентификатор
            }

        } catch (SQLException | ConnectionPoolException e) {
            // Обрабатываем SQLException
            throw new DaoException("Error adding news", e);
        }

        // Добавление информации об авторе новости
        if (authorId != 0) {
            try (Connection connection = connectionPool.takeConnection();
                 PreparedStatement stmt = connection.prepareStatement("INSERT INTO news_author (news_id, author_id) VALUES (?, ?)")) {

                // Устанавливаем параметры запроса для вставки информации об авторе новости
                stmt.setLong(1, newsId);
                stmt.setLong(2, authorId);

                // Выполняем запрос на вставку информации об авторе новости
                stmt.executeUpdate();

            } catch (SQLException | ConnectionPoolException e) {
                throw new DaoException("Error adding news author", e);
            }
        }

        // Обновляем список новостей после добавления новости и информации об авторе
        return newsId;
    }

    @Override
    public void connectTagsToNews(long newsId, List<Tag> tags) throws DaoException {
        // Соединение с базой данных и подготовка запроса
        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement("INSERT INTO news_tags (news_id, tag_id) VALUES (?, ?)")) {

            // Установка параметров запроса и выполнение запроса для каждой пары (news_id и tag_id)
            for (Tag tag : tags) {
                // Извлечение идентификатора тега из объекта Tag
                long tagId = tag.getId();

                // Установка параметров запроса
                stmt.setLong(1, newsId);
                stmt.setLong(2, tagId);

                // Выполнение запроса для вставки новой записи в таблицу `news_tags`
                stmt.executeUpdate();
            }
        } catch (SQLException | ConnectionPoolException e) {
            // Обрабатываем SQLException
            throw new DaoException("Error connecting tags to news", e);
        }
    }

    @Override
    public void addTagToNews(long newsId, long tagId) throws DaoException {
        // Добавление связи между новостью и тегом в базу данных
        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement("INSERT INTO news_tags (news_id, tag_id) VALUES (?, ?)")) {
            // Установка параметров запроса
            stmt.setLong(1, newsId);
            stmt.setLong(2, tagId);

            // Выполнение запроса на вставку новой записи
            stmt.executeUpdate();
        } catch (SQLException | ConnectionPoolException e) {
            // Обрабатываем SQLException
            throw new DaoException("Error adding tag to news", e);
        }
    }

    @Override
    public Collection<News> getAllNews() throws DaoException {
        Map<Long, News> newsList = new HashMap<>();

        try (Connection connection = connectionPool.takeConnection();
             Statement statement = connection.createStatement()) {

            // Execute the query to load data from the news table, including only active news and author information
            ResultSet rs = statement.executeQuery(getAllNewsSql);

            // Create a temporary map to store tags for each news
            Map<Long, List<Tag>> newsTagsMap = new HashMap<>();
            // Create a temporary map to store authors for each news
            Map<Long, Long> newsAuthorsMap = new HashMap<>();

            // Process the query results
            while (rs.next()) {
                long id = rs.getLong("id");
                String title = rs.getString("title");
                String brief = rs.getString("brief");
                String info = rs.getString("info");
                String imgPath = rs.getString("img_path");

                // Get the tag ID and name (if available)
                long tagId = rs.getLong("tag_id");
                String tagName = rs.getString("tag_name");

                // Create or get the news object from newsList
                News news = newsList.computeIfAbsent(id, k -> new News(id, title, brief, info, imgPath));

                // If there is a tag, add it to the news tags map
                if (tagId != 0) {
                    newsTagsMap.computeIfAbsent(id, k -> new ArrayList<>()).add(new Tag(tagId, tagName));
                }

                // Get the author ID
                long authorId = rs.getLong("author_id");

                // Save the author ID in the temporary map
                if (authorId != 0) {
                    newsAuthorsMap.put(id, authorId);
                }
            }

            // Set tags and authors in the news objects
            for (Map.Entry<Long, List<Tag>> entry : newsTagsMap.entrySet()) {
                long newsId = entry.getKey();
                List<Tag> tags = entry.getValue();
                News news = newsList.get(newsId);
                if (news != null) {
                    news.setTags(tags);
                }
            }

            UserManagerDaoImpl userManagerDao = UserManagerDaoImpl.getInstance();
            for (Map.Entry<Long, Long> entry : newsAuthorsMap.entrySet()) {
                long newsId = entry.getKey();
                long authorId = entry.getValue();
                News news = newsList.get(newsId);
                if (news != null) {
                    try {
                        User author = userManagerDao.getUserById(authorId); // Get the author of the news by their ID
                        news.setAuthor(author);
                    } catch (DaoException e) {
                        throw new DaoException(e);
                    }
                }
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Failed to fetch all news.", e);
        }

        return newsList.values();
    }

    @Override
    public News getNewsById(long id) throws DaoException {
        String query = getNewsByIdSqL;

        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setLong(1, id);
            ResultSet rs = stmt.executeQuery();

            News news = null;
            List<Tag> tags = new ArrayList<>();

            while (rs.next()) {
                if (news == null) {
                    long newsId = rs.getLong("id");
                    String title = rs.getString("title");
                    String brief = rs.getString("brief");
                    String info = rs.getString("info");
                    String imgPath = rs.getString("img_path");
                    long authorId = rs.getLong("author_id");
                    String authorName = rs.getString("author_name");
                    String authorRole = rs.getString("author_role"); // Fetching the author's role

                    news = new News(newsId, title, brief, info, imgPath);

                    if (authorId != 0) {
                        User author = new User(authorId, authorName, authorRole, null); // Assuming User constructor accepts id, name, and role
                        news.setAuthor(author);
                    }
                }

                long tagId = rs.getLong("tag_id");
                String tagName = rs.getString("tag_name");

                if (tagId != 0) {
                    tags.add(new Tag(tagId, tagName));
                }
            }

            if (news != null) {
                news.setTags(tags); // Assuming News class has a setTags method
                return news;
            } else {
                throw new DaoException("News with ID " + id + " not found.");
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Failed to fetch news by ID.", e);
        }
    }
}
