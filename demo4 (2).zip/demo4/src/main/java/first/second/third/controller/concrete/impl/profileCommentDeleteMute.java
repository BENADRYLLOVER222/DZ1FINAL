package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.service.*;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

public class profileCommentDeleteMute implements Command {
    private final CommentManager commentManager = ServiceProvider.getInstance().getCommentManager();
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Получаем текущую сессию
        HttpSession session = request.getSession(false);
        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        // Проверяем, что пользователь авторизован и имеет права модератора или администратора
        if (validator.validateMod(user.getRole())){
            try {
                // Получаем параметры из запроса
                long commentId = Long.parseLong(request.getParameter("commentId"));
                long profileId = Long.parseLong(request.getParameter("profileId"));
                String username = request.getParameter("username");

                // Добавляем пользователя в черный список
                userManager.addUserToBlacklist(username);

                // Удаляем комментарий
                commentManager.deleteComment(commentId);

                // Перенаправляем на профиль пользователя
                response.sendRedirect("MyController?command=go_to_user_profile&id=" + profileId);
            } catch (ServiceException e) {
                // Если возникла ошибка в сервисе, перенаправляем на страницу ошибки с сообщением об ошибке
                response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            } catch (NumberFormatException e) {
                // Если идентификатор комментария или профиля имеет неверный формат, перенаправляем на страницу ошибки
                response.sendRedirect("MyController?command=go_to_error_page&error=Invalid comment or profile ID format.");
            }
        } else {
            // Если пользователь не авторизован или не имеет достаточных прав, перенаправляем на страницу ошибки с сообщением об ошибке доступа
            response.sendRedirect("MyController?command=go_to_error_page&error=Unauthorized access");
        }
    }
}
