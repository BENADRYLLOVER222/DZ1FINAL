package first.second.third.dao.impl;

import first.second.third.bean.AuthInfo;
import first.second.third.bean.RegInfo;
import first.second.third.bean.User;
import first.second.third.dao.config.ConnectionPool;
import first.second.third.dao.config.ConnectionPoolException;
import first.second.third.dao.DaoException;
import first.second.third.dao.UserManagerDao;

import java.sql.*;
import java.util.*;

public final class UserManagerDaoImpl implements UserManagerDao {

    private static final UserManagerDaoImpl instance = new UserManagerDaoImpl();
    private static final ConnectionPool connectionPool = ConnectionPool.getInstance();

    private final Map<Long, User> userList = new HashMap<>();

    private UserManagerDaoImpl() {
        // Пустой приватный конструктор
    }
    public static UserManagerDaoImpl getInstance() {
        return instance;
    }

    private static final String signInSql = "SELECT u.id, u.name, u.password, u.pfp, r.role " +
            "FROM users_table u " +
            "JOIN user_role r ON u.id = r.user_id " +
            "WHERE u.name = ? AND u.password = ?";
    private static final String registrationSql = "INSERT INTO users_table (name, password) VALUES (?, ?)";
    private static final String updateUserRoleSql = "UPDATE user_role SET role = ? WHERE user_id = (SELECT id FROM users_table WHERE name = ?)";
   /*АДМИНЫ НЕ УДАЛЯЮТСЯ */ private static final String addUserToBlacklistSql = "UPDATE user_role SET role = 'muted' WHERE user_id = (SELECT id FROM users_table WHERE name = ?)";
    private static final String getUserByUsernameSql = "SELECT u.id, u.name, u.password, u.pfp, r.role " +
                "FROM users_table u " +
                "JOIN user_role r ON u.id = r.user_id " +
                "WHERE u.name = ?";
    private static final String getUserByIdSql = "SELECT u.id, u.name, u.password, u.pfp, r.role " +
                "FROM users_table u " +
                "JOIN user_role r ON u.id = r.user_id " +
                "WHERE u.id = ?";
    private static final String changeProfilePfpSql = "UPDATE users_table SET pfp = ? WHERE id = ?";
    private static final String getAllUsersSql = "SELECT u.id, u.name, u.password, u.pfp, r.role " +
                    "FROM users_table u " +
                    "JOIN user_role r ON u.id = r.user_id";



    @Override
    public User signIn(AuthInfo authInfo) throws DaoException {
        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement(signInSql)) {

            stmt.setString(1, authInfo.getLogin());
            stmt.setString(2, authInfo.getPassword());

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    long id = rs.getLong("id");
                    String name = rs.getString("name");
                    String role = rs.getString("role");
                    String password = rs.getString("password");
                    String pfp = rs.getString("pfp");

                    User user = new User(id, name, role, password);
                    user.setPfp(pfp);
                    return user;
                }
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error during sign in", e);
        }

        return null;
    }

    @Override
    public void registration(RegInfo regInfo) throws DaoException {
        String login = regInfo.getUsername();
        String password = regInfo.getPassword();

        User existingUser = getUserByUsername(login);
        if (existingUser != null) {
            throw new DaoException("User with username " + login + " already exists");
        }

        try (Connection conn = connectionPool.takeConnection()) {
            conn.setAutoCommit(false);

            try {
                try (PreparedStatement pstmtUser = conn.prepareStatement(registrationSql, Statement.RETURN_GENERATED_KEYS)) {
                    pstmtUser.setString(1, login);
                    pstmtUser.setString(2, password);
                    pstmtUser.executeUpdate();

                    try (ResultSet generatedKeys = pstmtUser.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            long userId = generatedKeys.getLong(1);

                            String sqlInsertRole = "INSERT INTO user_role (role, user_id) VALUES (?, ?)";
                            try (PreparedStatement pstmtRole = conn.prepareStatement(sqlInsertRole)) {
                                pstmtRole.setString(1, "user");
                                pstmtRole.setLong(2, userId);
                                pstmtRole.executeUpdate();
                            }
                        } else {
                            throw new SQLException("Creating user failed, no ID obtained.");
                        }
                    }
                }

                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw new DaoException("Error during registration", e);
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Database connection error", e);
        }
    }

    @Override
    public void updateUserRole(String username, String newRole) throws DaoException {
        // SQL-запрос для изменения роли пользователя по его имени

        try (Connection conn = connectionPool.takeConnection();
             PreparedStatement updateUserRoleStmt = conn.prepareStatement(updateUserRoleSql)) {

            // Устанавливаем значения параметров для запроса обновления роли пользователя
            updateUserRoleStmt.setString(1, newRole); // Устанавливаем новую роль
            updateUserRoleStmt.setString(2, username); // Устанавливаем имя пользователя

            // Выполняем запрос обновления роли пользователя
            int rowsUpdated = updateUserRoleStmt.executeUpdate();
            if (rowsUpdated == 0) {
                // Если ни одна строка не была обновлена, значит пользователь с таким именем не найден
                throw new DaoException("User not found with username: " + username);
            }
        } catch (SQLException | ConnectionPoolException e) {
            // Обработка исключений
            throw new DaoException("Failed to update user role", e);
        }
    }

    @Override
    public void addUserToBlacklist(String username) throws DaoException {
        // SQL-запрос для изменения роли пользователя на 'muted' по имени пользователя

        try (Connection conn = connectionPool.takeConnection();
             PreparedStatement updateUserRoleStmt = conn.prepareStatement(addUserToBlacklistSql)) {

            // Устанавливаем параметр для запроса
            updateUserRoleStmt.setString(1, username);

            // Выполняем запрос обновления роли пользователя
            int rowsUpdated = updateUserRoleStmt.executeUpdate();
            if (rowsUpdated == 0) {
                // Если ни одна строка не была обновлена, значит пользователь с таким именем не найден
                throw new DaoException("User not found with username: " + username);
            }
        } catch (SQLException | ConnectionPoolException e) {
            // Обработка исключений
            throw new DaoException("Error adding user to blacklist", e);
        }
    }

    @Override
    public User getUserByUsername(String username) throws DaoException {

        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement(getUserByUsernameSql)) {

            stmt.setString(1, username);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    long id = rs.getLong("id");
                    String name = rs.getString("name");
                    String role = rs.getString("role");
                    String password = rs.getString("password");
                    String pfp = rs.getString("pfp");

                    User user = new User(id, name, role, password);
                    user.setPfp(pfp);
                    return user;
                } else {
                    // No rows found, throw exception
                    throw new DaoException("No user found with username: " + username);
                }
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error fetching user by username", e);
        }
    }

    @Override
    public User getUserById(long id) throws DaoException {
        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement(getUserByIdSql)) {

            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    long userId = rs.getLong("id");
                    String name = rs.getString("name");
                    String role = rs.getString("role");
                    String password = rs.getString("password");
                    String pfp = rs.getString("pfp");

                    User user = new User(userId, name, role, password);
                    user.setPfp(pfp);
                    return user;
                }
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error fetching user by ID", e);
        }

        return null;
    }

    @Override
    public void changeProfilePfp(long userId, String newPfp) throws DaoException {
        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement statement = connection.prepareStatement(changeProfilePfpSql)) {
            statement.setString(1, newPfp);
            statement.setLong(2, userId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated == 0) {
                throw new DaoException("Failed to update profile picture for user with ID: " + userId);
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error updating profile picture for user with ID: " + userId, e);
        }
    }


    @Override
    public Collection<User> getAllUsers() throws DaoException {
        Collection<User> users = new ArrayList<>();

        try (Connection connection = connectionPool.takeConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(getAllUsersSql)) {

            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String role = rs.getString("role");
                String password = rs.getString("password");
                String pfp = rs.getString("pfp");

                User user = new User(id, name, role, password);
                user.setPfp(pfp);
                users.add(user);
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error fetching all users", e);
        }

        return users;
    }
}
