package first.second.third.controller.concrete.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import first.second.third.bean.News;
import first.second.third.bean.Tag;
import first.second.third.controller.concrete.Command;
import first.second.third.service.*;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class GoToMainPage implements Command {

	private static final NewsManager newsManager = ServiceProvider.getInstance().getNewsManager();
	private static final TagManager tagManager = ServiceProvider.getInstance().getTagManager();
	private static final Validator validator = UtilsProvider.getInstance().getValidator();

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);

		if (validator.sessionPresence(session) && validator.userPresence(session.getAttribute("user"))) {
			try {
				tagManager.deleteUnusedTags();
				List<News> allNews = new ArrayList<>(newsManager.getAllNews());
				List<Tag> allTags = new ArrayList<>(tagManager.getAllTags());

				// Pagination parameters
				int newsPerPage = 10; // Number of news items per page
				int currentPage = request.getParameter("page") != null ? Integer.parseInt(request.getParameter("page")) : 1;
				int totalNews = allNews.size();
				int totalPages = (int) Math.ceil((double) totalNews / newsPerPage);

				int start = (currentPage - 1) * newsPerPage;
				int end = Math.min(start + newsPerPage, totalNews);

				List<News> newsPage = allNews.subList(start, end);

				// Set pagination attributes
				request.setAttribute("currentPage", currentPage);
				request.setAttribute("totalPages", totalPages);
				request.setAttribute("mainNews", newsPage);

				// Determine the size of the tag list and the last 7 tags
				int tagSize = allTags.size();
				int numberOfTagsToGet = Math.min(7, tagSize); // Take the minimum of 7 and the total number of tags

				// Extract the last 7 tags from the list
				List<Tag> latestTags = allTags.subList(tagSize - numberOfTagsToGet, tagSize);

				// Set the last 7 tags as a request attribute
				request.setAttribute("latestTags", latestTags);

				RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/news.jsp");
				dispatcher.forward(request, response);
			} catch (ServiceException e) {
				System.out.println("Error during getting news");
				response.sendRedirect("MyController?command=go_to_error_page&error=An error occurred during getting news.");
			}
		} else {
			response.sendRedirect("MyController?command=go_to_index_page&authError=You cannot perform this action. Please log in!");
		}
	}
}