package first.second.third.service;

import first.second.third.bean.News;
import first.second.third.bean.Tag;

import java.util.Collection;
import java.util.List;

public interface NewsManager {
    void deleteNewsById(long id) throws ServiceException;

   /* void newsRefresh() throws ServiceException; */

    long newsAdd(String title, String brief, String info, String imgPath, long authorId) throws ServiceException;

    List<News> getNewsByTagId(long tagId) throws ServiceException;

    List<Tag> getTagsByNewsId(long newsId) throws ServiceException;

    void connectTagsToNews(long newsId, List<Tag> tags) throws ServiceException;

    void addTagToNews(long newsId, long tagId) throws ServiceException;

    Collection<News> getAllNews() throws ServiceException;

    void updateNewsById(long id, String title, String brief, String info, String imgPath) throws ServiceException;

    News getNewsById(long id) throws ServiceException;

}

