package first.second.third.service.impl;

import first.second.third.bean.AuthInfo;
import first.second.third.bean.RegInfo;
import first.second.third.bean.User;
import first.second.third.dao.DaoException;
import first.second.third.dao.DaoProvider;
import first.second.third.dao.UserManagerDao;
import first.second.third.service.ServiceException;
import first.second.third.service.UserManager;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import first.second.third.utils.impl.ValidatorImpl;

import java.util.Collection;


public final class UserManagerImpl implements UserManager {
    private UserManagerDao userManagerDao = DaoProvider.getInstance().getUserManagerDao();
    private final Validator validator = UtilsProvider.getInstance().getValidator();


    @Override
    public void updateUserRole(String username, String newRole) throws ServiceException {
       try{
           userManagerDao.updateUserRole(username, newRole);
       } catch (DaoException e) {
           throw new ServiceException(e);
       }
    }

    @Override
    public void addUserToBlacklist(String username) throws ServiceException {
        try{
            userManagerDao.addUserToBlacklist(username);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public User getUserByUsername(String username) throws ServiceException {
        try{
            return userManagerDao.getUserByUsername(username);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public User getUserById(long id) throws ServiceException {
        try{
            return userManagerDao.getUserById(id);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public void changeProfilePfp(long userId, String newPfp) throws ServiceException {
        try{
            userManagerDao.changeProfilePfp(userId, newPfp);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public Collection<User> getAllUsers() throws ServiceException {
        try{
            return userManagerDao.getAllUsers();
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public void registration(RegInfo regInfo) throws ServiceException {
        try {
            validator.regValidator(regInfo);
            userManagerDao.registration(regInfo);
        } catch (UtilException | DaoException e) {
            throw new ServiceException("Error occurred while validating registration information", e);
        }
    }

    @Override
    public User signIn(AuthInfo authInfo) throws ServiceException {
        try{
            return userManagerDao.signIn(authInfo);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }
}