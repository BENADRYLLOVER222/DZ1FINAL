package first.second.third.service;

import first.second.third.bean.Tag;

import java.util.Collection;
import java.util.List;

public interface TagManager {

    List<Tag> getOrAddTagsByNames(List<String> tagNames) throws ServiceException;

    Tag getTagById(long tagId) throws ServiceException;

    Collection<Tag> getAllTags() throws ServiceException;

    void deleteTagsFromNews(long newsId) throws ServiceException;

    List<String> tagHandling(String tagsStr);

    void deleteUnusedTags() throws ServiceException;}


