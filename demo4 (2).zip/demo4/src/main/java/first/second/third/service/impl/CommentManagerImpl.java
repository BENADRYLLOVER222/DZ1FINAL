package first.second.third.service.impl;

import first.second.third.bean.Comment;
import first.second.third.dao.CommentManagerDao;
import first.second.third.dao.DaoException;
import first.second.third.dao.DaoProvider;
import first.second.third.dao.impl.CommentManagerDaoImpl;
import first.second.third.service.CommentManager;
import first.second.third.service.ServiceException;

import java.util.List;

public class CommentManagerImpl implements CommentManager {

    private CommentManagerDao commentManagerDao = DaoProvider.getInstance().getCommentManagerDao();


    @Override
    public int countUserComments(long userId) throws ServiceException {
        try {
            return commentManagerDao.countUserComments(userId);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public long addComment(long userId, long entityId, String commentText, CommentManagerDaoImpl.EntityType entityType) throws ServiceException {
        try{
            return commentManagerDao.addComment(userId, entityId, commentText, entityType);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public List<Comment> getCommentsByEntityId(long entityId, CommentManagerDaoImpl.EntityType entityType) throws ServiceException {
        try{
            return commentManagerDao.getCommentsByEntityId(entityId, entityType);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }

    }


    @Override
    public void deleteComment(long commentId) throws ServiceException {
        try{
            commentManagerDao.deleteComment(commentId);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

}
