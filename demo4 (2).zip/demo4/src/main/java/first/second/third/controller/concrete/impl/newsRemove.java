package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.NewsManager;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.utils.Validator;

import java.io.IOException;

public class newsRemove implements Command {
    private final NewsManager newsManager = ServiceProvider.getInstance().getNewsManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        String role = user.getRole();
        if (!validator.validateEditor(role)) {
            response.sendRedirect("MyController?command=go_to_error_page&error=Unauthorized access");
            return;
        }

        try {
            // Get news id from request parameter
            long id = Long.parseLong(request.getParameter("newsId"));

            // Attempt to delete the news
            newsManager.deleteNewsById(id);

            // If deletion is successful, redirect to the main page
            response.sendRedirect("MyController?command=go_to_main_page");
        } catch (NumberFormatException e) {
            // If newsId is not a valid number, redirect to error page with invalid identifier format message
            response.sendRedirect("MyController?command=go_to_error_page&error=Invalid news identifier format.");
        } catch (ServiceException e) {
            // If there is a service exception, redirect to error page with error message
            response.sendRedirect("MyController?command=go_to_error_page&error=Error deleting news.");
        }
    }
}