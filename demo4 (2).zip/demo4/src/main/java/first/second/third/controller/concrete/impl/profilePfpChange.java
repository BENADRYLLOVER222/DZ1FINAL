package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;
import first.second.third.utils.Validator;

import java.io.IOException;

public class profilePfpChange implements Command {
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Получаем текущего пользователя из сессии
        HttpSession session = request.getSession(false);

        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        // Проверяем наличие пользователя в сессии и совпадение его ID с параметром userId из запроса
        if (validator.validateId(user.getId(), Long.parseLong(request.getParameter("userId")))) {
            try {
                // Получаем параметры из запроса
                long userId = user.getId();
                String pfp = request.getParameter("image");

                // Меняем изображение профиля пользователя
                userManager.changeProfilePfp(userId, pfp);

                // Перенаправляем на страницу профиля пользователя
                response.sendRedirect("MyController?command=go_to_user_profile&id=" + userId);
            } catch (ServiceException e) {
                // Если возникла ошибка в сервисе, перенаправляем на страницу ошибки с сообщением об ошибке
                response.sendRedirect("MyController?command=go_to_error_page&error=Error changing profile picture");
            } catch (NumberFormatException e) {
                // Если параметр userId имеет неверный формат числа, перенаправляем на страницу ошибки
                response.sendRedirect("MyController?command=go_to_error_page&error=Invalid user ID");
            } catch (IOException e) {
                // Если произошла ошибка ввода-вывода при перенаправлении, перенаправляем на страницу ошибки
                response.sendRedirect("MyController?command=go_to_error_page&error=Error occurred during redirection.");
            }
        } else {
            // Если пользователь не найден в сессии или его ID не совпадает с параметром userId из запроса, перенаправляем на страницу ошибки доступа
            response.sendRedirect("MyController?command=go_to_error_page&error=Unauthorized access");
        }
    }
}
