package first.second.third.controller.concrete.impl;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import first.second.third.bean.RegInfo;
import first.second.third.controller.concrete.Command;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;

public class DoRegistration implements Command {
	private final UserManager userService = ServiceProvider.getInstance().getUserManager();

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Get login, password, and password repeat from the request
		String login = request.getParameter("login");
		String password = request.getParameter("password");
		String passwordRepeat = request.getParameter("passwordRepeat");

		// Check if login and password are provided
		if (login == null || password == null) {
			redirectToRegistrationPage(response, "Login and password are required");
			return;
		}

		// Check if passwords match
		if (!password.equals(passwordRepeat)) {
			redirectToRegistrationPage(response, "Passwords do not match");
			return;
		}

		// Validate login and password
		if (!validateLoginAndPassword(login, password)) {
			redirectToRegistrationPage(response, "Login or password contains invalid characters. Only Latin letters, digits, and underscores are allowed.");
			return;
		}

		// Create a RegInfo object and call the registration method
		RegInfo regInfo = new RegInfo(login, password, passwordRepeat);
		try {
			userService.registration(regInfo);
			redirectToIndexPage(response, "Registration successful!");
		} catch (ServiceException e) {
			System.out.println("Error registering user. Login: " + login);
			redirectToRegistrationPage(response, e.getMessage());
		}
	}

	private boolean validateLoginAndPassword(String login, String password) {
		// Check if login and password contain only Latin letters, digits, and underscores
		return login.matches("[a-zA-Z0-9_]+") && password.matches("[a-zA-Z0-9_]+");
	}

	private void redirectToRegistrationPage(HttpServletResponse response, String errorMessage) throws IOException {
		response.sendRedirect("MyController?command=go_to_registration_page&error=" + URLEncoder.encode(errorMessage, StandardCharsets.UTF_8));
	}

	private void redirectToIndexPage(HttpServletResponse response, String successMessage) throws IOException {
		response.sendRedirect("MyController?command=go_to_index_page&error=" + URLEncoder.encode(successMessage, StandardCharsets.UTF_8));
	}
}