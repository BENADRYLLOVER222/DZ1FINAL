package first.second.third.dao;

import first.second.third.bean.AuthInfo;
import first.second.third.bean.RegInfo;
import first.second.third.bean.User;
import java.util.Collection;

public interface UserManagerDao {

    public void updateUserRole(String username, String newRole) throws DaoException;
    public void addUserToBlacklist(String username) throws DaoException;
    public User getUserByUsername(String username) throws DaoException;
    public User getUserById(long id) throws DaoException;
    public void changeProfilePfp(long userId, String newPfp) throws DaoException;
    public Collection<User> getAllUsers() throws DaoException;
    void registration(RegInfo regInfo) throws DaoException;
    User signIn(AuthInfo authInfo) throws  DaoException;
}

