package first.second.third.service.impl;

import first.second.third.bean.Tag;
import first.second.third.dao.DaoException;
import first.second.third.dao.DaoProvider;
import first.second.third.dao.TagManagerDao;
import first.second.third.service.ServiceException;
import first.second.third.service.TagManager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class TagManagerImpl implements TagManager {
    private TagManagerDao tagManagerDao = DaoProvider.getInstance().getTagManagerDao();


    @Override
    public List<Tag> getOrAddTagsByNames(List<String> tagNames) throws ServiceException {
        try{
            return tagManagerDao.getOrAddTagsByNames(tagNames);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public Tag getTagById(long tagId) throws ServiceException {
        try {
            return tagManagerDao.getTagById(tagId);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public Collection<Tag> getAllTags() throws ServiceException {
        try {
            return tagManagerDao.getAllTags();
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public void deleteTagsFromNews(long newsId) throws ServiceException {
        try {
            tagManagerDao.deleteTagsFromNews(newsId);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public void deleteUnusedTags() throws ServiceException {
        try {
            tagManagerDao.deleteUnusedTags();
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }
    public List<String> tagHandling(String tagsStr){
        List<String> tagsList = new ArrayList<>();

        if (tagsStr != null && !tagsStr.isEmpty()) {
            // Разделяем строку на массив строк по запятым
            String[] tagsArray = tagsStr.split(",");

            // Обрезаем пробелы до и после каждого тега
            for (String tag : tagsArray) {
                String trimmedTag = tag.trim();

                // Добавляем обрезанный тег в список
                if (!trimmedTag.isEmpty()) {
                    tagsList.add(trimmedTag);
                }
            }
        }
        return tagsList;
    }
}
