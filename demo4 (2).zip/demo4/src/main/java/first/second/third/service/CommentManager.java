package first.second.third.service;

import first.second.third.bean.Comment;
import first.second.third.dao.impl.CommentManagerDaoImpl;

import java.util.List;

public interface CommentManager {
    int countUserComments(long userId) throws ServiceException;

    long addComment(long userId, long entityId, String commentText, CommentManagerDaoImpl.EntityType entityType) throws ServiceException;

    List<Comment> getCommentsByEntityId(long entityId, CommentManagerDaoImpl.EntityType entityType) throws ServiceException;

    void deleteComment(long commentId) throws ServiceException;

}