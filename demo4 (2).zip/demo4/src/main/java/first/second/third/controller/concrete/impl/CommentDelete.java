package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.CommentManager;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.utils.Validator;

import java.io.IOException;
import java.sql.SQLException;

public class CommentDelete implements Command {

    private final CommentManager commentManager = ServiceProvider.getInstance().getCommentManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();


    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        String role = user.getRole();
        long userId = user.getId();
        long requestUserId;
        long commentId;
        long newsId;

        try {
            requestUserId = Long.parseLong(request.getParameter("userId"));
            commentId = Long.parseLong(request.getParameter("commentId"));
            newsId = Long.parseLong(request.getParameter("newsId"));
        } catch (NumberFormatException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=Invalid parameters");
            return;
        }

        if (!validator.validateMod(role) && !validator.validateId(userId, requestUserId)) {
            response.sendRedirect("MyController?command=go_to_error_page&error=Permission denied");
            return;
        }

        try {
            commentManager.deleteComment(commentId);
            response.sendRedirect("MyController?command=go_to_news_details&id=" + newsId);
        } catch (ServiceException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=Service error: " + e.getMessage());
        }
    }
}