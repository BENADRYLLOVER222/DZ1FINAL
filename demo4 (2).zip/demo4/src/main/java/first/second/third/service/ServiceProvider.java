package first.second.third.service;

import first.second.third.service.impl.*;
import first.second.third.utils.Validator;
import first.second.third.utils.impl.ValidatorImpl;

public final class ServiceProvider {
	private static final ServiceProvider instance = new ServiceProvider();

	private NewsManager newsManager = new NewsManagerImpl();
	private TagManager tagManager = new TagManagerImpl();
	private UserManager userManager = new UserManagerImpl();
	private CommentManager commentManager = new CommentManagerImpl();
	private Validator validator = new ValidatorImpl();

	private ServiceProvider() {}

	public static ServiceProvider getInstance() {return instance;}

	public UserManager getUserManager() {return userManager;}

	public NewsManager getNewsManager() {return newsManager;}

	public TagManager getTagManager() {return tagManager;}

	public CommentManager getCommentManager() {return commentManager;}

	public Validator getValidator() {return validator;}

}
