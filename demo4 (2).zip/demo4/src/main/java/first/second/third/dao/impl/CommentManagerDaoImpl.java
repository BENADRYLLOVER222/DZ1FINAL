package first.second.third.dao.impl;

import first.second.third.bean.Comment;
import first.second.third.bean.User;
import first.second.third.dao.config.ConnectionPool;
import first.second.third.dao.config.ConnectionPoolException;
import first.second.third.dao.CommentManagerDao;
import first.second.third.dao.DaoException;

import java.sql.*;
import java.util.*;



public class CommentManagerDaoImpl implements CommentManagerDao {
    private static final CommentManagerDaoImpl instance = new CommentManagerDaoImpl();
    private static final ConnectionPool connectionPool = ConnectionPool.getInstance();


    // Приватный конструктор для предотвращения создания экземпляров
    private CommentManagerDaoImpl() {
        // Пустой приватный конструктор
    }
    public enum EntityType {
        NEWS("news_id"),
        PROFILE("profile_id");

        public final String columnName;

        private EntityType(String columnName){
            this.columnName = columnName;
        }
    }

    private static final String countUserCommentsSql = "SELECT COUNT(*) AS comment_count FROM Comments WHERE user_id = ? AND is_active = true";


    public static CommentManagerDaoImpl getInstance() {
        return instance;
    }

    public long addComment(long userId, long entityId, String commentText, EntityType entityType) throws DaoException {
        String sql = "";
        long commentId = -1;

        sql = "INSERT INTO Comments (user_id," +  entityType.columnName +  ", comment_text) VALUES (?, ?, ?)";

        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setLong(1, userId);
            statement.setLong(2, entityId);
            statement.setString(3, commentText);

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating comment failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    commentId = generatedKeys.getLong(1);
                } else {
                    throw new SQLException("Creating comment failed, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
            throw new DaoException("Error adding comment", e);
        } catch (ConnectionPoolException e) {
            throw new DaoException("Error getting connection from pool", e);
        }
        return commentId;
    }


    @Override
    public int countUserComments(long userId) throws DaoException {
        int count = 0;

        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement statement = connection.prepareStatement(countUserCommentsSql)) {

            // Set query parameter
            statement.setLong(1, userId);

            // Execute query and process results
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    count = resultSet.getInt("comment_count");
                }
            }

        } catch (SQLException e) {
            throw new DaoException("SQL error occurred while counting user comments", e);
        } catch (ConnectionPoolException e) {
            throw new DaoException("Error obtaining connection from the connection pool", e);
        }

        return count;
    }

    @Override
    public List<Comment> getCommentsByEntityId(long entityId, EntityType entityType) throws DaoException {
        List<Comment> comments = new ArrayList<>();
        String sql = "";
        sql = "SELECT c.comment_id, c.user_id, c.comment_text, c.comment_date, u.name, ur.role, u.pfp " +
                        "FROM Comments c " +
                        "JOIN users_table u ON c.user_id = u.id " +
                        "JOIN user_role ur ON u.id = ur.user_id " +
                        "WHERE c." +  entityType.columnName + "= ? AND c.is_active = true";
        try (Connection connection = connectionPool.takeConnection(); // Получаем соединение из пула
             PreparedStatement statement = connection.prepareStatement(sql)) {
            // Устанавливаем параметр запроса
            statement.setLong(1, entityId);

            // Выполняем запрос
            try (ResultSet resultSet = statement.executeQuery()) {
                // Обрабатываем результаты запроса
                while (resultSet.next()) {
                    long commentId = resultSet.getLong("comment_id");
                    long userId = resultSet.getLong("user_id");
                    String commentText = resultSet.getString("comment_text");
                    Timestamp commentTimestamp = resultSet.getTimestamp("comment_date");
                    String name = resultSet.getString("name");
                    String role = resultSet.getString("role");
                    String pfp = resultSet.getString("pfp");

                    // Создаем объект пользователя
                    User user = new User(userId, name, role, null);
                    user.setPfp(pfp);
                    Comment comment = new Comment(commentId, commentText, user);
                    comment.setDate(commentTimestamp);
                    // Добавляем комментарий в список
                    comments.add(comment);
                }
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error getting comments by entity id", e);
        }
        return comments;
    }

    @Override
    public void deleteComment(long commentId) throws DaoException {
        String sql = "UPDATE Comments SET is_active = false WHERE comment_id = ?";

        try (Connection connection = connectionPool.takeConnection(); // Получаем соединение из пула
             PreparedStatement statement = connection.prepareStatement(sql)) {
            // Устанавливаем параметр запроса
            statement.setLong(1, commentId);

            // Выполняем запрос
            int rowsAffected = statement.executeUpdate();

            // Проверяем количество обновленных записей
            if (rowsAffected == 0) {
                throw new DaoException("Comment with ID " + commentId + " not found");
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error updating comment with ID " + commentId, e);
        }
    }
}
