package first.second.third.controller.concrete.impl;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.service.*;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class newsAdd implements Command {
	private final NewsManager newsManager = ServiceProvider.getInstance().getNewsManager();
	private final TagManager tagManager = ServiceProvider.getInstance().getTagManager();
	private final Validator validator = UtilsProvider.getInstance().getValidator();

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		try{
			validator.validateAuth(session, validator);
		}catch(UtilException e){
			response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
			return;
		}
		User user = (User) session.getAttribute("user");
		String role = user.getRole();
		if (!(validator.validateEditor(role))) {
			redirectToErrorPage(response, "You are not authorized to perform this action");
			return;
		}
		try {
			String title = request.getParameter("title");
			String brief = request.getParameter("brief");
			String info = request.getParameter("info");
			String imagePath = request.getParameter("image");
			String tagsStr = request.getParameter("tags");
			long id = user.getId();

			List<String> tagsList = new ArrayList<>();

			if (tagsStr != null && !tagsStr.isEmpty()) {
				String[] tagsArray = tagsStr.split(",");

				for (String tag : tagsArray) {
					String trimmedTag = tag.trim();

					if (!trimmedTag.isEmpty()) {
						tagsList.add(trimmedTag);
					}
				}
			}

			long newsId = newsManager.newsAdd(title, brief, info, imagePath, id);
			newsManager.connectTagsToNews(newsId, tagManager.getOrAddTagsByNames(tagsList));

			response.sendRedirect("MyController?command=go_to_main_page");
		} catch (ServiceException e) {
			redirectToErrorPage(response, "Error during adding news");
		}
	}

	private void redirectToErrorPage(HttpServletResponse response, String errorMessage) throws IOException {
		response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode(errorMessage, StandardCharsets.UTF_8));
	}
}
