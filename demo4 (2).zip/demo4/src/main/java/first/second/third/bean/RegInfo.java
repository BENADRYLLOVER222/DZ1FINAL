package first.second.third.bean;

public class RegInfo {
    private String username;
    private String password;
    private String repeatPassword;


    public RegInfo(String username, String password, String repeatPassword) {
        this.username = username;
        this.password = password;
        this.repeatPassword = repeatPassword;
    }


    public String getRepeatPassword() {
        return repeatPassword;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

