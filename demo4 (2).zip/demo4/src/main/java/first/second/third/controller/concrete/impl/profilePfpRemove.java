package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;
import first.second.third.utils.Validator;

import java.io.IOException;

public class profilePfpRemove implements Command {
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        // Получаем идентификатор пользователя из параметра запроса
        String userIdParam = request.getParameter("userId");
        String profileIdParam = request.getParameter("profileId");
        if (userIdParam == null || userIdParam.isEmpty()) {
            // Если идентификатор пользователя отсутствует в запросе, перенаправляем на страницу ошибки с сообщением
            response.sendRedirect("MyController?command=go_to_error_page&error=Missing userId parameter");
            return;
        }

        // Проверяем роль пользователя
        if (!validator.validateMod(user.getRole())){
            // Если пользователь не является модератором или администратором, перенаправляем на страницу ошибки с сообщением
            response.sendRedirect("MyController?command=go_to_error_page&error=Unauthorized access");
            return;
        }

        try {
            // Преобразуем идентификатор пользователя в число
            long userId = Long.parseLong(userIdParam);
            long profileId = Long.parseLong(profileIdParam);

            // Изменяем изображение профиля пользователя на заданное
            userManager.changeProfilePfp(profileId, "https://i.pinimg.com/474x/25/1c/e1/251ce139d8c07cbcc9daeca832851719.jpg");

            // Перенаправляем на страницу профиля пользователя
            response.sendRedirect("MyController?command=go_to_user_profile&id=" + profileId);
        } catch (NumberFormatException e) {
            // Если идентификатор пользователя имеет неверный формат числа, перенаправляем на страницу ошибки с сообщением
            response.sendRedirect("MyController?command=go_to_error_page&error=Invalid user ID");
        } catch (ServiceException e) {
            // Если возникла ошибка в сервисе, перенаправляем на страницу ошибки с сообщением
            response.sendRedirect("MyController?command=go_to_error_page&error=Error changing profile picture");
        }
    }
}
//дота 2 для