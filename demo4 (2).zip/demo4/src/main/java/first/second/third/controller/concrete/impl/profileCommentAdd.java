package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.dao.impl.CommentManagerDaoImpl;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.CommentManager;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.utils.Validator;

import java.io.IOException;

public class profileCommentAdd implements Command {
    private final CommentManager commentManager = ServiceProvider.getInstance().getCommentManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Проверяем наличие сессии
        HttpSession session = request.getSession(false);
        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        try {
            // Получаем параметры из запроса
            long userId = user.getId();
            long profileId = Long.parseLong(request.getParameter("profileId"));
            String text = request.getParameter("comment");

            // Проверяем роль пользователя и что он не замучен
            if (!validator.validateMuted(user.getRole()) && validator.validateId(userId, Long.parseLong(request.getParameter("userId")))) {
                // Добавляем комментарий и перенаправляем на страницу профиля
                long newCommentId = commentManager.addComment(userId, profileId, text, CommentManagerDaoImpl.EntityType.PROFILE);
                response.sendRedirect("MyController?command=go_to_user_profile&id=" + profileId + "&newCommentId=" + newCommentId);
            } else {
                // Если пользователь замучен или пытается комментировать не свой профиль, перенаправляем на страницу ошибки
                response.sendRedirect("MyController?command=go_to_error_page&error=Unauthorized comment");
            }
        } catch (NumberFormatException e) {
            // Если профиль не найден или идентификатор комментария не является числом, перенаправляем на страницу ошибки
            response.sendRedirect("MyController?command=go_to_error_page&error=Invalid profile or comment identifier format");
        } catch (ServiceException e) {
            // Если произошла ошибка при добавлении комментария, перенаправляем на страницу ошибки
            response.sendRedirect("MyController?command=go_to_error_page&error=Error adding comment");
        }
    }
}
