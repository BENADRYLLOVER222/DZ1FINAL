package first.second.third.dao;

import first.second.third.bean.News;
import first.second.third.bean.Tag;

import java.util.*;

public interface NewsManagerDao {

    /*public void newsRefresh() throws DaoException; */
    public long newsAdd(String title, String brief, String info, String imgPath, long authorId) throws DaoException;
    public List<News> getNewsByTagId(long tagId) throws DaoException;
    void deleteNewsById(long id) throws DaoException;
    public List<Tag> getTagsByNewsId(long newsId) throws DaoException;
    public void connectTagsToNews(long newsId, List<Tag> tags) throws DaoException;
    public void updateNewsById(long id, String title, String brief, String info, String imgPath) throws DaoException;
    public void addTagToNews(long newsId, long tagId) throws DaoException;
    public Collection<News> getAllNews() throws DaoException;
    public News getNewsById(long id) throws DaoException;
}
