package first.second.third.dao.impl;

import first.second.third.bean.Tag;
import first.second.third.dao.config.ConnectionPool;
import first.second.third.dao.config.ConnectionPoolException;
import first.second.third.dao.DaoException;
import first.second.third.dao.TagManagerDao;

import java.sql.*;
import java.util.*;

public class TagManagerDaoImpl implements TagManagerDao {

    private static final TagManagerDaoImpl instance = new TagManagerDaoImpl();
    private static final ConnectionPool connectionPool = ConnectionPool.getInstance();



    private TagManagerDaoImpl() {
        // Пустой приватный конструктор
    }

    public static TagManagerDaoImpl getInstance() {
        return instance;
    }

    private static final String getOrAddTagsByNamesCheckExistanceSql = "SELECT id, name FROM tags WHERE name = ?";
    private static final String getOrAddTagsByNamesInsertNewTagSql = "INSERT INTO tags (name) VALUES (?)";
    private static final String getTagByIdSql = "SELECT id, name FROM tags WHERE id = ?";
    private static final String getAllTagsSql = "SELECT id, name FROM tags";
    private static final String deleteTagsFromNewsSql = "DELETE FROM news_tags WHERE news_id = ?";
    private static final String deleteUnusedTagsSql = "DELETE FROM tags WHERE id NOT IN (SELECT DISTINCT tag_id FROM news_tags)";
    @Override
    public List<Tag> getOrAddTagsByNames(List<String> tagNames) throws DaoException {
        List<Tag> tags = new ArrayList<>();
        try (Connection connection = connectionPool.takeConnection()) {
            // Подготовленный запрос для поиска существующего тега
            PreparedStatement checkStmt = connection.prepareStatement(getOrAddTagsByNamesCheckExistanceSql);

            // Подготовленный запрос для добавления нового тега
            PreparedStatement insertStmt = connection.prepareStatement(getOrAddTagsByNamesInsertNewTagSql, Statement.RETURN_GENERATED_KEYS);

            // Перебираем каждый тег в списке названий тегов
            for (String tagName : tagNames) {
                // Обрезаем пробелы вокруг названия тега
                tagName = tagName.trim();

                // Устанавливаем название тега в запросе для проверки
                checkStmt.setString(1, tagName);

                // Выполняем запрос на проверку существования тега
                ResultSet rs = checkStmt.executeQuery();

                Tag tag;
                if (rs.next()) {
                    // Если тег существует, получаем его id и добавляем в список тегов
                    long tagId = rs.getLong("id");
                    tag = new Tag(tagId, tagName);
                } else {
                    // Если тег не существует, добавляем его
                    insertStmt.setString(1, tagName);

                    // Выполняем запрос на добавление нового тега
                    insertStmt.executeUpdate();

                    // Получаем сгенерированный id нового тега
                    ResultSet generatedKeys = insertStmt.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        long tagId = generatedKeys.getLong(1);
                        tag = new Tag(tagId, tagName);
                    } else {
                        // Если не удалось получить сгенерированный id, выбрасываем исключение
                        throw new SQLException("Failed to retrieve generated key for new tag");
                    }
                }
                // Добавляем тег в список тегов
                tags.add(tag);
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException(e);
        }

        return tags;
    }

    @Override
    public Tag getTagById(long tagId) throws DaoException {
        try (Connection connection = connectionPool.takeConnection();
             PreparedStatement stmt = connection.prepareStatement(getTagByIdSql)) {

            stmt.setLong(1, tagId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                return new Tag(id, name);
            } else {
                return null;
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error fetching tag by ID", e);
        }
    }

    @Override
    public Collection<Tag> getAllTags() throws DaoException {
        List<Tag> tags = new ArrayList<>();
        try (Connection connection = connectionPool.takeConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(getAllTagsSql)) {

            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                tags.add(new Tag(id, name));
            }
        } catch (SQLException | ConnectionPoolException e) {
            throw new DaoException("Error fetching all tags", e);
        }

        return tags;
    }



    @Override
    public void deleteTagsFromNews(long newsId) throws DaoException {
        // Соединение с базой данных
        try (Connection connection = connectionPool.takeConnection()) {
            try (PreparedStatement stmt = connection.prepareStatement(deleteTagsFromNewsSql)) {
                stmt.setLong(1, newsId);
                stmt.executeUpdate();
            }
        } catch (SQLException | ConnectionPoolException e) {
            // Обработка исключения SQLException
            throw new DaoException("Error deleting tags from news", e);
        }
    }

    @Override
    public void deleteUnusedTags() throws DaoException {
        // Соединение с базой данных
        try (Connection connection = connectionPool.takeConnection()) {
            // Подготовка запроса для удаления неиспользуемых тегов из таблицы `tags`
            String deleteQuery = "DELETE FROM tags WHERE id NOT IN (SELECT DISTINCT tag_id FROM news_tags)";
            try (PreparedStatement stmt = connection.prepareStatement(deleteUnusedTagsSql)) {
                stmt.executeUpdate();
            }
        } catch (SQLException | ConnectionPoolException e) {
            // Обработка исключения SQLException
            throw new DaoException("Error deleting unused tags", e);
        }
    }
}