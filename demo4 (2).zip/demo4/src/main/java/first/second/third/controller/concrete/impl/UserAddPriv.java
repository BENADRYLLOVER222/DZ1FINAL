package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;
import first.second.third.utils.Validator;

import java.io.IOException;

public class UserAddPriv implements Command {
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        if (validator.validateAdmin(user.getRole())) {
            try {
                // Получаем имя пользователя и новую роль из запроса
                String username = request.getParameter("useraddpriv");
                String privToAdd = request.getParameter("role_add");

                userManager.updateUserRole(username, privToAdd);

                response.sendRedirect("MyController?command=go_to_user_manager");

            } catch (ServiceException e) {
                response.sendRedirect("MyController?command=go_to_error_page&error=Error adding role");
            }
        }
    }
}