package first.second.third.controller.concrete.impl;

import first.second.third.bean.News;
import first.second.third.controller.concrete.Command;
import first.second.third.dao.impl.CommentManagerDaoImpl;
import first.second.third.service.*;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import first.second.third.bean.User;

import java.io.IOException;
import java.sql.SQLException;

public class newsCommentAdd implements Command {
    private final CommentManager commentManager = ServiceProvider.getInstance().getCommentManager();
    private final NewsManager newsManager = ServiceProvider.getInstance().getNewsManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            try{
                validator.validateAuth(request.getSession(false), validator);
            }catch (UtilException e){
                response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
                return;
            }
            User user = (User) request.getSession().getAttribute("user");
            if (validator.userPresence(user) && !validator.validateMuted(user.getRole()) && validator.validateId(user.getId(),Long.parseLong(request.getParameter("userId")))) {
                long userId = Long.parseLong(request.getParameter("userId"));
                System.out.println("userId: " + userId);
                long newsId = Long.parseLong(request.getParameter("newsId"));
                System.out.println("newsId: " + newsId);

                // Проверяем, существует ли новость
                News news = newsManager.getNewsById(newsId);
                if (news != null) {
                    String text = request.getParameter("comment");
                    System.out.println("comment: " + text);

                    long newCommentId = commentManager.addComment(userId, newsId, text, CommentManagerDaoImpl.EntityType.NEWS);
                    response.sendRedirect("MyController?command=go_to_news_details&id=" + newsId + "&newCommentId=" + newCommentId);
                } else {
                    // Перенаправление на страницу с сообщением об ошибке, если новость не существует
                    response.sendRedirect("MyController?command=go_to_error_page&error=News not found");
                }
            } else {
                response.sendRedirect("MyController?command=go_to_index_page&authError=You are not authorized to perform this action.");
            }
        } catch (ServiceException e) {
            // Обработка ошибки добавления комментария
            long newsId = Long.parseLong(request.getParameter("newsId"));
            response.sendRedirect("MyController?command=go_to_error_page&error=Error adding comment");
        } catch (NumberFormatException e) {
            // Обработка ошибки парсинга идентификатора новости
            response.sendRedirect("MyController?command=go_to_error_page&error=Invalid news ID");
        }
    }
}