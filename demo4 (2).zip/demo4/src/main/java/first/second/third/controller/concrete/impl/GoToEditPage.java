package first.second.third.controller.concrete.impl;

import first.second.third.bean.News;
import first.second.third.bean.Tag;
import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.service.*;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class GoToEditPage implements Command {

    private final NewsManager newsManager = ServiceProvider.getInstance().getNewsManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        try{
            validator.validateAuth(session, validator);
        }catch(UtilException e){
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        String role = user.getRole();
        if (!validator.validateEditor(role)) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("Unauthorized access", StandardCharsets.UTF_8));
            return;
        }

        try {
            long newsId = Long.parseLong(request.getParameter("id"));

            News news = newsManager.getNewsById(newsId);
            List<Tag> tags = newsManager.getTagsByNewsId(newsId);
            request.setAttribute("news", news);
            request.setAttribute("tags", tags);

            RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/edit.jsp");
            dispatcher.forward(request, response);
        } catch (ServiceException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("Error retrieving news.", StandardCharsets.UTF_8));
        } catch (NumberFormatException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + URLEncoder.encode("Invalid news identifier format.", StandardCharsets.UTF_8));
        }
    }
}