package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;
import first.second.third.service.ServiceProvider;
import first.second.third.service.UserManager;
import first.second.third.utils.Validator;

import java.io.IOException;

public class UserAddToBlacklist implements Command {
    private final UserManager userManager = ServiceProvider.getInstance().getUserManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);

        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        if (validator.validateMod(user.getRole())) {
            try {
                // Получаем имя пользователя из запроса
                String username = request.getParameter("username");

                // Если имя пользователя не пустое
                if (username != null && !username.isEmpty() && !validator.validateAdmin(userManager.getUserByUsername(username).getRole())) {
                    // Используем метод `addUserToBlacklist` для добавления пользователя в черный список
                    userManager.addUserToBlacklist(username);

                    // Перенаправляем пользователя в зависимости от результата операции
                    response.sendRedirect("MyController?command=go_to_user_manager");
                } else {
                    response.sendRedirect("MyController?command=go_to_error_page&error=User does not exist or you are trying to add an admin to the blacklist");
                }
            } catch (ServiceException e) {
                response.sendRedirect("MyController?command=go_to_error_page&error=An error occurred while adding user to blacklist: " + e.getMessage());
            }
        }
    }
}