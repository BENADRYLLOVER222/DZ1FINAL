package first.second.third.controller.concrete.impl;

import first.second.third.bean.News;
import first.second.third.bean.Tag;
import first.second.third.controller.concrete.Command;
import first.second.third.service.*;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

public class GoToNewsByTag implements Command {
    private final NewsManager newsManager = ServiceProvider.getInstance().getNewsManager();
    private final TagManager tagManager = ServiceProvider.getInstance().getTagManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (validator.sessionPresence(session) && validator.userPresence(session.getAttribute("user"))) {
            try {
                long tagId = Long.parseLong(request.getParameter("id"));
                List<News> newsList = newsManager.getNewsByTagId(tagId);
                Tag tag = tagManager.getTagById(tagId);
                System.out.println("tag: " + tag.getName() + "tag id: " + tag.getId());
                request.setAttribute("tag", tag);
                request.setAttribute("mainNews", newsList);

                RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/news-by-tag.jsp");
                dispatcher.forward(request, response);
            } catch (ServiceException e) {
                response.sendRedirect("MyController?command=go_to_error_page&error=Tag not found");
            } catch (NumberFormatException e) {
                response.sendRedirect("MyController?command=go_to_error_page&error=Invalid tag ID");
            }
        } else {
            // If the user is not authenticated, redirect them to the login page
            response.sendRedirect("MyController?command=go_to_index_page&authError=You cannot perform this action. Please log in!");
        }
    } // конец метода
}