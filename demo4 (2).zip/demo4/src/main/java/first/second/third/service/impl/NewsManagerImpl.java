package first.second.third.service.impl;

import first.second.third.bean.News;
import first.second.third.bean.Tag;
import first.second.third.dao.DaoException;
import first.second.third.dao.NewsManagerDao;
import first.second.third.dao.DaoProvider;
import first.second.third.service.NewsManager;
import first.second.third.service.ServiceException;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import first.second.third.utils.impl.ValidatorImpl;

import java.util.Collection;
import java.util.List;

public class NewsManagerImpl implements NewsManager {
    private NewsManagerDao newsManagerDao = DaoProvider.getInstance().getNewsManagerDao();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void deleteNewsById(long id) throws ServiceException {
        try{
            newsManagerDao.deleteNewsById(id);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public long newsAdd(String title, String brief, String info, String imgPath, long authorId) throws ServiceException {
        // Проверка на маты в заголовке, кратком описании и информации
        try{
            validator.containsProfanity(title);
            validator.containsProfanity(brief);
            validator.containsProfanity(info);
        } catch (UtilException e) {
            throw new ServiceException(e);
        }
        try {
            return newsManagerDao.newsAdd(title, brief, info, imgPath, authorId);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public List<News> getNewsByTagId(long tagId) throws ServiceException {
        try {
            return newsManagerDao.getNewsByTagId(tagId);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public List<Tag> getTagsByNewsId(long newsId) throws ServiceException {
        try {
            return newsManagerDao.getTagsByNewsId(newsId);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public void connectTagsToNews(long newsId, List<Tag> tags) throws ServiceException {
        // Проверка на отрицательные или нулевые значения аргументов
        if (newsId <= 0) {
            throw new ServiceException("Invalid news ID: " + newsId);
        }
        if (tags == null || tags.isEmpty()) {
            throw new ServiceException("Tag list is empty.");
        }

        try {
            newsManagerDao.connectTagsToNews(newsId, tags);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }


    @Override
    public void addTagToNews(long newsId, long tagId) throws ServiceException {
        // Проверка на отрицательные или нулевые значения аргументов
        if (newsId <= 0) {
            throw new ServiceException("Invalid news ID: " + newsId);
        }
        if (tagId <= 0) {
            throw new ServiceException("Invalid tag ID: " + tagId);
        }

        try {
            newsManagerDao.addTagToNews(newsId, tagId);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }


    @Override
    public Collection<News> getAllNews() throws ServiceException {
        try {
            return newsManagerDao.getAllNews();
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public void updateNewsById(long id, String title, String brief, String info, String imgPath) throws ServiceException {
        try {
            newsManagerDao.updateNewsById(id, title, brief, info, imgPath);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public News getNewsById(long id) throws ServiceException {
        try {
            return newsManagerDao.getNewsById(id);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
    }

}
