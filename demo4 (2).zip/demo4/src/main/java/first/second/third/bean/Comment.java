package first.second.third.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

public class Comment implements Serializable {
    private static final long serialVersionUID = 1L;

    private long id;
    private String text;
    private User user;
    private Timestamp date;

    public Comment(long id, String text, User user) {
        this.id = id;
        this.text = text;
        this.user = user;
        this.date = date;
    }

    public void setDate(Timestamp date) {this.date = date;}

    public Timestamp getDate() {return date;}

    public long getId() {return id;}

    public String getText() {return text;}

    public User getUser() {return user;}

    public void setId(long id) {this.id = id;}

    public void setText(String text) {this.text = text;}

    public void setUser(User user) {this.user = user;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Comment comment = (Comment) o;
        return id == comment.id && Objects.equals(text, comment.text) && Objects.equals(user, comment.user);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, text, user);
    }

    @Override
    public String toString() {
        return "Comment{" +
                "id=" + id +
                ", text='" + text + '\'' +
                ", user=" + user +
                '}';
    }
}
