package first.second.third.controller.concrete.impl;

import first.second.third.bean.User;
import first.second.third.controller.concrete.Command;
import first.second.third.service.*;
import first.second.third.utils.UtilException;
import first.second.third.utils.UtilsProvider;
import first.second.third.utils.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class newsEdit implements Command {
    private final NewsManager newsManager = ServiceProvider.getInstance().getNewsManager();
    private final TagManager tagManager = ServiceProvider.getInstance().getTagManager();
    private final Validator validator = UtilsProvider.getInstance().getValidator();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        try {
            validator.validateAuth(session, validator);
        } catch (UtilException e) {
            response.sendRedirect("MyController?command=go_to_error_page&error=" + e.getMessage());
            return;
        }
        User user = (User) session.getAttribute("user");
        String role = user.getRole();
        if (!validator.validateEditor(role)) {
            // Если пользователь не администратор или редактор, перенаправляем на страницу ошибки
            response.sendRedirect("MyController?command=go_to_error_page&error=Unauthorized access");
            return;
        }
        try {
            // Получаем параметры запроса
            long id = Long.parseLong(request.getParameter("id"));
            String title = request.getParameter("title");
            String brief = request.getParameter("brief");
            String info = request.getParameter("info");
            String imagePath = request.getParameter("image");
            String tagsStr = request.getParameter("tags");

            List<String> tagsList = new ArrayList<>();

            if (tagsStr != null && !tagsStr.isEmpty()) {
                // Разделяем строку на массив строк по запятым
                String[] tagsArray = tagsStr.split(",");

                // Обрезаем пробелы до и после каждого тега
                for (String tag : tagsArray) {
                    String trimmedTag = tag.trim();

                    // Добавляем обрезанный тег в список
                    if (!trimmedTag.isEmpty()) {
                        tagsList.add(trimmedTag);
                    }
                }
            }

            // Обновляем новость и ее теги
            newsManager.updateNewsById(id, title, brief, info, imagePath);
            tagManager.deleteTagsFromNews(id);
            newsManager.connectTagsToNews(id, tagManager.getOrAddTagsByNames(tagsList));

            response.sendRedirect("MyController?command=go_to_main_page");
        } catch (NumberFormatException e) {
            // Если идентификатор новости имеет некорректный формат, перенаправляем на страницу ошибки
            response.sendRedirect("MyController?command=go_to_error_page&error=Invalid news identifier format");
        } catch (ServiceException e) {
            // В случае ошибки при обновлении новости, перенаправляем на страницу ошибки
            response.sendRedirect("MyController?command=go_to_error_page&error=Error during updating news");
        }
    }
}