package first.second.third.service;

import first.second.third.bean.AuthInfo;
import first.second.third.bean.RegInfo;
import first.second.third.bean.User;

import java.util.Collection;

public interface UserManager {

    void updateUserRole(String username, String newRole) throws ServiceException;

    void addUserToBlacklist(String username) throws ServiceException;

    User getUserByUsername(String username) throws ServiceException;

    User getUserById(long id) throws ServiceException;

    void changeProfilePfp(long userId, String newPfp) throws ServiceException;

    Collection<User> getAllUsers() throws ServiceException;

    void registration(RegInfo regInfo) throws ServiceException;

    User signIn(AuthInfo authInfo) throws ServiceException;
}
