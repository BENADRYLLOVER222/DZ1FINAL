package first.second.third.controller.concrete.impl;
import java.io.IOException;

import first.second.third.controller.concrete.Command;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceProvider;
import first.second.third.utils.Validator;

public class  Logout implements Command {
	private final Validator validator = ServiceProvider.getInstance().getValidator();
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);

		// Проверяем, есть ли активная сессия и атрибут "user"
		if (validator.sessionPresence(session) && validator.userPresence(session.getAttribute("user"))) {
			// Удаляем атрибут "user" из сессии
			session.removeAttribute("user");
			//session.invalidate();
		}

		// Создаем cookie с тем же именем, что и cookie "remember-me"
		Cookie rememberMeCookie = new Cookie("remember-me", "");
		// Устанавливаем срок действия в 0, чтобы удалить cookie
		rememberMeCookie.setMaxAge(0);
		// Устанавливаем путь, если у вас есть специальный путь для cookie
		rememberMeCookie.setPath(request.getContextPath());
		// Отправляем cookie на клиент, чтобы удалить его
		response.addCookie(rememberMeCookie);

		// Перенаправляем пользователя на страницу с сообщением о выходе из системы
		response.sendRedirect("MyController?command=go_to_index_page&authError=You've been unlogged!");
	}

}
