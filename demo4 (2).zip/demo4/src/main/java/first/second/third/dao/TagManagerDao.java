package first.second.third.dao;

import first.second.third.bean.Tag;
import java.util.*;

public interface TagManagerDao {

    public List<Tag> getOrAddTagsByNames(List<String> tagNames) throws DaoException;
    public Tag getTagById(long tagId) throws DaoException;
    public Collection<Tag> getAllTags() throws DaoException;
    public void deleteTagsFromNews(long newsId) throws DaoException;
    public void deleteUnusedTags() throws DaoException;
}
