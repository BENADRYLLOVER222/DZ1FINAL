package first.second.third.utils;

import first.second.third.utils.impl.ValidatorImpl;

public class UtilsProvider {
    private static final UtilsProvider instance = new UtilsProvider();

    public static UtilsProvider getInstance() {return instance;}

    private Validator validator = new ValidatorImpl();

    private UtilsProvider() {}

    public Validator getValidator() {return validator;}
}
