package first.second.third.dao.impl;

import first.second.third.dao.DaoException;
import first.second.third.dao.config.ConnectionPool;
import first.second.third.dao.config.ConnectionPoolException;
import first.second.third.dao.config.DBParameter;
import first.second.third.dao.config.DBResourceManager;

import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SQLDao {
    private static final Logger logger = Logger.getLogger(SQLDao.class.getName());

    // Статический блок инициализации класса
    static {
        DBResourceManager dbResourceManager = DBResourceManager.getInstance();
        String driverName = dbResourceManager.getValue(DBParameter.DB_DRIVER);

        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            // Логирование ошибки
            logger.log(Level.SEVERE, "Unable to load database driver class", e);

            // Выбрасываем unchecked исключение для остановки выполнения программы
            throw new ExceptionInInitializerError(e);
        }
    }

    // Прочие методы класса, например для работы с ConnectionPool
}