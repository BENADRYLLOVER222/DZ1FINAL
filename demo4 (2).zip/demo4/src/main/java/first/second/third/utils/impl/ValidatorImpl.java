package first.second.third.utils.impl;

import first.second.third.bean.RegInfo;
import first.second.third.utils.UtilException;
import first.second.third.utils.Validator;
import jakarta.servlet.http.HttpSession;
import first.second.third.service.ServiceException;

public class ValidatorImpl implements Validator {

    public void regValidator(RegInfo regInfo) throws UtilException {
        // Проверка на null
        if (regInfo == null) {
            throw new UtilException("Registration information is null");
        }

        // Проверка на корректность ввода данных в regInfo
        String login = regInfo.getUsername();
        String password = regInfo.getPassword();
        String passwordRepeat = regInfo.getRepeatPassword();
        if (login == null || login.isEmpty() || password == null || password.isEmpty() || passwordRepeat == null || passwordRepeat.isEmpty()) {
            throw new UtilException("Invalid registration information: login, password or password repeat is empty");
        }

        // Проверка на совпадение паролей
        if (!password.equals(passwordRepeat)) {
            throw new UtilException("Passwords do not match");
        }

        // Проверка на наличие только латинских букв, цифр и нижних подчеркиваний в логине и пароле
        if (!login.matches("[a-zA-Z0-9_]+") || !password.matches("[a-zA-Z0-9_]+")) {
            throw new UtilException("Invalid characters in login or password. Only Latin letters, digits, and underscores are allowed.");
        }
    }

    public boolean validateRole(String role) throws UtilException {
        if (role == null || role.isEmpty()) {
            throw new UtilException("Role is not specified");
        } else {
            // Role-specific validations
            switch (role.toLowerCase()) {
                case "admin":
                case "editor":
                case "moderator":
                case "user":
                case "muted":
                    return true; // Роль соответствует допустимым значениям
                default:
                    throw new UtilException("Invalid role specified");
            }
        }
    }
    @Override
    public void validateAuth(HttpSession session, Validator validator) throws UtilException {

        if (!validator.sessionPresence(session)) {
            throw new UtilException("Session is not present");
        }
        try{
            session.getAttribute("user");
        } catch (NullPointerException e) {
            throw new UtilException("Session is not present");
        }
        if (!validator.userPresence(session.getAttribute("user"))) {
            throw new UtilException("User is not present");
        }
    }

    private static final String[] PROFANITY_LIST = {"badword1", "badword2", "badword3"};

    // Метод проверки на наличие матерных слов в тексте
    public boolean containsProfanity(String text) throws UtilException {
        // Приведение текста к нижнему регистру для унификации сравнения
        text = text.toLowerCase();

        // Проверка наличия матерных слов или выражений в тексте
        for (String profanity : PROFANITY_LIST) {
            if (text.contains(profanity)) {
                throw new UtilException("Text contains profanity"); // Найдено матерное слово или выражение
            }
        }

        return false; // Матерных слов или выражений не обнаружено
    }

    public boolean validateAdmin(String role) {
        return "admin".equalsIgnoreCase(role);
    }
    public boolean validateMod(String role) {return "moderator".equalsIgnoreCase(role) || "admin".equalsIgnoreCase(role);}
    public boolean validateEditor(String role) {return "editor".equalsIgnoreCase(role) || "admin".equalsIgnoreCase(role);}
    public boolean validateMuted(String role) {
        return "muted".equalsIgnoreCase(role);
    }
    public boolean validateUser(String role) {
        return "user".equalsIgnoreCase(role);
    }
    public boolean userPresence(Object user){
        return user != null;
    }
    public boolean sessionPresence(HttpSession session){
        return session != null;
    }
    public boolean validateId(long id1, long id2){
        return id1 == id2;
    }
}
